<?php

<!DOCTYPE html>	
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="UAE No.1Onsite car battery replacement service in Dubai, Abu Dhabi, Sharjah" />
<meta name="keywords" content="Car battery replacement dubai, Car battery replacement, Car battery Dubai, Car battery abu dhabi, battery change dubai, car battery" />
    <meta name="author" content="">
    <title>Call A Battery - Onsite Car Battery Replacement Service in Dubai, Abu Dhabi and Sharjah</title>
    
    
    
    
	<!-- Bootstrap CSS -->
	<link href="csss/bootstrap.min.css" rel="stylesheet">
     <!-- CSS Custom -->
     
    <link rel="stylesheet" type="text/css" href="csss/stylenew.css">
    <link href="csss/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="csss/animate.min.css">

	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>



</head>
<body>


<header class="navbar-fixed-top">

	<div class="container">
    	<div class="row">
        	<div class="header_top">
            
                
        		<div class="col-md-2">
            		<div class="logo_img">
						<a href="#"><img src="images/logo.png" alt="Onsite Car Battery"></a>
					</div>
				</div>
					
				<div class="col-md-7" style="margin-top:25px;">
					<div class="menu_bar">	
						<nav role="navigation" class="navbar navbar-default">
							<div class="navbar-header">
                                <button id="menu_slide"  aria-controls="navbar" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                  </button>
							   </div>
							   
							  <div class="collapse navbar-collapse" id="navbar">
                            
								<ul class="nav navbar-nav">
								  <li><a href="#home" class="js-target-scroll">Home</a></li>
								  <li><a href="#service" class="js-target-scroll">Services</a></li>
								  <li><a href="#checkup" class="js-target-scroll">Checkup</a></li>
								  <li><a href="#brands" class="js-target-scroll">Brands</a></li>
                                   <li><a href="#cars" class="js-target-scroll">Cars</a></li>
								  <li><a href="#faq" class="js-target-scroll">FAQ</a></li>
							    <li><a href="#contact" class="js-target-scroll">Contact</a><li>									                                </ul>      
                          	</div>
                            
						</nav>
                        
                        
                        
					</div>
    	        </div>
                
             <div class="col-md-2">
            		<div class="logo_img">
						<div class="section_btnnew"></span>	
                        	
						<span> <a href="tel:800622437"> <button class="btn btn-default" type="submit"><i class=" " aria-hidden="true"></i> Call Us : 800-622-437</button> </a> 
						</span>
						
						</div>
					</div>
				</div>
                </div>
			  
			  </div>
			</div>
		</div>
</header>

<section id="home" class="top_banner_bg secondary-bg">
	<div class="container">
		<div class="row">
		  <div class="col-md-12">
				<div class="top_banner">
				
				</div>
				
			<div class="col-md-6 rowfixtext">
					<div class="present">
						<h1> UAE No.1 On site Car Battery service, We Provide Onsite Car Battery Service at Your Door Step </h1>
						
						<h5> 24/7 <span> Onsite </span> Battery <b> Support</b> </h5>
						
						<div class="section_btn"></span>	
                        	
						<span> <a href="tel:800622437"> <button class="btn btn-default" type="submit" style="line-height:40px;"> <span style="font-size:20px;">Call Us Now</span><br><i class="fa fa-phone-square" aria-hidden="true"></i><span style="font-size:35px;"> 800-622-437 </span></button> </a></span>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 rowfiximg ">
					<div class="present_img">
						<img src="images/image-1.png" alt="car battery dubai">
					</div>
				</div>
				
			</div>
	  </div>
	</div>
</section>


<section id="service" class="primary-bg">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
			
			<div class="section_heading">
				<h2> Awesome Car Battery Replacement Service in Dubai and Abu Dhabi </h2>
				
				<h4> We Provide Onsite Car Battery Replacement Service in Duabi, Abu Dhabi, Sharjah And All Over UAE. If you need emergency help with your car battery replacement, please call us immediately at: <div class="section_btn"></span>	
                        	
						<span> <a href="tel: 800-622- 437"> <button class="btn btn-default" type="submit"><i class="fa fa-phone-square" aria-hidden="true"></i> 800-622-437</button> </a> 					</span>
                        
                        
						<h2 style="font-size:14px; padding-top:30px; padding-bottom:30px;">
                        
                        
                       <p> Call a battery is a professional Car battery replacement service in Dubai and Abu Dhabi, specialized in the field of car battery replacement services. We have fixated ourselves in the modern ways of servicing and providing dedicated battery replacement services to our customers. We ensure to arrive your location within 30 – 45 minutes or even earlier and to complete servicing before 10 minutes otherwise, we will inform you before arranging an appointment without over-promising.</p>
 
<p>Our mechanics are equipped with the necessary expertise skills and equipment to effectively perform 24hrs car battery replacement, executing car battery jump start for all types of vehicle that includes cars battery, vans battery, motorbike battery and even super cars.</p>
 
<p>We offer the best affordable and good quality car battery price to our customers.  Every battery provided by call-a-Battery comes with 12 to 18 months warranty.</p>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        </h2>
                        
                        
				</div></h4>
			</div>		
				
			<div class="col-md-6">
				<div class="features_detail">
					<ul>
						<li>
							
								<i class="fa fa-user" aria-hidden="true"></i> 
								<h5> QUICK SUPPORT</h5>
								We provide onsite battery replacement support in Duabi, Abu Dhabi and Sharjah.
							
						</li>
						
						<li>
							
								<i class="fa fa-fighter-jet" aria-hidden="true"></i> 
								<h5>QUICK SERVICE</h5>
								We provide onsite battery replacement service with in 30 minutes.
						</li>
						
						<li>
							
								<i class="fa  fa-clock-o" aria-hidden="true"></i> 
								<h5> 24/7 SUPPORT</h5>
								Our support team will provide 24/7 support.
						</li>
						
						<li>
							
								<i class="fa  fa-thumbs-up" aria-hidden="true"></i> 
								<h5> WARRANTY</h5>
								We provide 12 to 18 months warranty with every battery we replace.
						</li>
					</ul>
				</div>
			</div>
			
				<div class="col-md-6">
					<div class="features_img pull-left">
						<img src="images/features_img.png" alt="UAE NO:1 onsite battery replacement">
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>


<section id="checkup" class="primary-bg">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			
				<div class="section_heading">
					<h2> How it work </h2>
					
					<h4>We offer four point car battery replacement testing for your vehicle at your door step and 24/7 onsite help in UAE</h4>
				</div>		
				
				<div class="col-md-4">
					<div class="how_it_work_m text-right">
						<a href="#"> <i class="fa fa-phone-square" aria-hidden="true"></i> </a>
						<a href="tel:800622437"> <h5> Call Us - 800-622- 437</h5> </a>
						<p>Call us our toll free, Our well trained car battery techicians will come to your place within 30 minutes!  </p>
					</div>
					
					<div class="how_it_work_m text-right">
						<a href="#"> <i class="fa  fa-battery-full " aria-hidden="true"></i> </a>
						<a href="#"> <h5> Car Battery Replacement</h5> </a>
						<p> We have all top brands car batteries available with 12 to 18 months warranty.   </p>
					</div>
				</div>
				
				<div class="col-md-4">
								<div class="workng_img">
									<img src="images/how_to_work.png" alt="car battery abu dhabi">
								</div>
				</div>
				
				<div class="col-md-4">
					<div class="how_it_work_m text-left">
						<a href="#"><i class="fa fa-gears" aria-hidden="true"></i> </a>
						<a href="#"> <h5> Car Battery Test </h5> </a>
						<p> We offer four point testing for your car battery at your door step. </p>
					</div>
					
					<div class="how_it_work_m text-left">
						<a href="#"> <i class="fa  fa-support " aria-hidden="true"></i> </a>
						<a href="#"> <h5>24/7 Customer Support </h5> </a>
						<p> We provide 24/7 Car battery replacment support in UAE. </p>
					</div>
				</div>

				
			</div>
		</div>
	</div>
</section>



<section id="brands" class="fifth-bg">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="col-md-3 rowfix" >
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="section_heading">
                  <h2> OUR BRANDS</h2>
                  <h4> We have all top brands car batteries available at very good price and service!! </h4>
                </div>
                <div class="col-md-3">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/deta.png" alt="car battery for deta"> </div>
                    <div class="member_name">
                      <h5> DETA BATTERY</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/amaron.png" alt="car battery for amaron"> </div>
                    <div class="member_name">
                      <h5> AMARON</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/optima.png" alt="car battery for optima"> </div>
                    <div class="member_name">
                      <h5> OPTIMA</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/acdelco.png" alt="acdelco"> </div>
                    <div class="member_name">
                      <h5> AC DELCO</h5>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-3 rowfix">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/bosch.png" alt="car battery for bosch"> </div>
                    <div class="member_name">
                      <h5> BOSCH</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 rowfix">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/varta.png" alt="car battery for varta"> </div>
                    <div class="member_name">
                      <h5> VARTA</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 rowfix">
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/trogen_agm.png" alt="car battery for trogan"> </div>
                    <div class="member_name">
                      <h5> TROGEN AGM</h5>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 rowfix" >
                  <div class="member_detail">
                    <div class="member_img"> <img src="images/honkook.png" alt="car battery for hankook"> </div>
                    <div class="member_name">
                      <h5> HANKOOK</h5>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section id="cars" class="fifth-bg" style="background:#FFF;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			
				<div class="section_heading">
					<h2> CARS</h2>
					
					<h4>Few of the car manufacturers' batteries we supply: </h4>
				</div>		
					

					<div class="portfolio_img">
						<div class="port_img1">
							<img src="images/portfolio2.png" alt="car-battery-duabi">
						</div>
					</div>
								
			</div>
		</div>
	</div>
</section>



<section id="faq" class="primary-bg " style="margin:auto !important;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			
			<div class="section_heading">
				<h2>Frequently Asked Questions </h2>
				
				<h4>Call A Battery  battery replacement service that provides the perfect battery solutions at your door step. </h4>
			</div>		
				
				
        	<div role="tablist" id="accordion1" class="panel-group ">
                    	                        
                            <div class="panel panel-default">
								<div role="tab" class="panel-heading">
									<h4 class="panel-title">
										<a href="#collapse1" data-parent="#accordion1" data-toggle="collapse" role="button" aria-expanded="true" class="">
                                        	<div class="font-icon-m">
											<i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i>
                                            </div>
											 How to check the Health of the battery? ?  	 
										</a>
									</h4>
								</div>
								<div role="tabpanel" class="panel-collapse collapse in" id="collapse1" aria-expanded="true" style="">
									<div class="panel-body">
										<p>If voltmeter is giving + 12.2 Volts, this can start the Alternator. </p>
									</div>
								</div>
							</div>
                            
                            <div class="panel panel-default">
								<div role="tab" class="panel-heading">
									<h4 class="panel-title">
										<a href="#collapse2" data-parent="#accordion1" data-toggle="collapse" role="button" class="collapsed" aria-expanded="false">
                                        	<div class="font-icon-m">
											<i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i>
                                            </div>
									What to do, if Battery doesn't show enough Voltage?
										</a>
									</h4>
								</div>
								<div role="tabpanel" class="panel-collapse collapse" id="collapse2" aria-expanded="false" style="height: 0px;">
									<div class="panel-body">
										<p>Either get battery recharged and then re-test it or Replace the old with new battery. </p>
                                
									</div>
								</div>
							</div>
                            
                         
                            <div class="panel panel-default">
								<div role="tab" class="panel-heading">
									<h4 class="panel-title">
										<a href="#collapse3" data-parent="#accordion1" data-toggle="collapse" role="button" class="collapsed" aria-expanded="false">
                                        	<div class="font-icon-m">
											<i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i>
                                            </div>
											 What is an Importance of Battery with Alternator?	 
										</a>
									</h4>
								</div>
								<div role="tabpanel" class="panel-collapse collapse" id="collapse3" aria-expanded="false" style="height: 0px;">
									<div class="panel-body">
										<p>The headlights draw power from the battery, just as ignition, audio, starter motor and everything else. If the alternator fails or doesn't deliver enough power all of these will continue to draw from the battery until it is empty. The battery won't recharge (properly) anymore, however. When the battery is discharged completely all electric equipment including the headlights (and most painfully the starter motor) will stop working. </p>
                                   
									</div>
								</div>
							</div>
                            
                            <div class="panel panel-default">
								<div role="tab" class="panel-heading">
									<h4 class="panel-title">
										<a href="#collapse4" data-parent="#accordion1" data-toggle="collapse" role="button" class="collapsed" aria-expanded="false">
                                        	<div class="font-icon-m">
											<i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i>
                                            </div>
											The electrical lights and air works, but my car won't turn on. Could it be an alternator problem?
										</a>
									</h4>
								</div>
								<div role="tabpanel" class="panel-collapse collapse" id="collapse4" aria-expanded="false" style="height: 0px;">
									<div class="panel-body">
										<p>You need to have your alternator tested. If your alternator is good, it might be the starter. If it's not your alternator or starter, you have another problem. It could be a timing belt or timing chain. </p>
                                   
									</div>
								</div>
							</div>
                            
                           <div class="panel panel-default">
								
                                
                                <div role="tab" class="panel-heading">
									<h4 class="panel-title">
										<a href="#collapse5" data-parent="#accordion1" data-toggle="collapse" role="button" class="collapsed" aria-expanded="false">
                                        	<div class="font-icon-m">
											<i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i>
                                            </div>
											How to avoid battery failure causing car break down?
										</a>
									</h4>
								</div>
                                
								<div role="tabpanel" class="panel-collapse collapse" id="collapse5" aria-expanded="false" style="height: 0px;">
									<div class="panel-body">
										<p>Each Car battery works up to +5 years and one should get their battery checked on within each couple of years. It also helps to reduce the chances of failure.</p>
                                    
									</div>
								</div>
							</div>
                             </div>	
		  </div>
		</div>
	</div>
</section>


<section id="contact" class="contact_bg">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section_heading section_heading_2">
					<h2> Instant Call Back </h2>
				
					<h4>Let drop a line to us & we will be in touch soon. </h4>
				</div>
							
				<div class="col-md-6">
					<div class="contact_form">
					<form method="" name="contactform" action="http://callabattery.ae/dubai-car-battery-service.html">
					  <div class="form-group">
						<label >Full Name : <span> *</span></label>
						<input type="email" class="form-control" id="exampleInputEmail1" >
					  </div>
                      
                       <div class="form-group">
						<label >Phone : <span> *</span></label>
						<input type="phone" class="form-control" id="exampleInputEmail1" >
					  </div>
					  
									  
					  <div class="form-group">
						<label>Message <span> </span></label>
						<textarea class="form-textarea" rows="3"></textarea>
					 </div>
					  
					    <div class="section_sub_btn">
							<button class="btn btn-default" type="submit">  Send Message</button>	
						</div>
					</form> 
					</div>
				</div>
				
				<div class="col-md-6">
					<div class="contact_text">
						<ul>
							<li>
								<span><i class="fa fa-home" aria-hidden="true"></i></span> 
								<h5> PO Box: 410775, Dubai United Arab Emirates.</h5>
							</li>
							
							<li>
								<span><i class="fa fa-envelope-o" aria-hidden="true"></i></span> 
								<h5> help@callabattery.ae </h5>
							</li>
							
							<li>
								<span><a href="tel:800622437" style="color:#ff8e00;"><i class="fa fa-phone" aria-hidden="true"></i></a></span> 
							<a href="tel:800622437">	<h5> 800-622- 437 </h5></a>
							</li>
                            
                            <li>
								<span><i class="fa fa-whatsapp" aria-hidden="true"></i></span> 
							<a href="https://wa.me/971569984153?text=I'm%20interested%20in%20your%20battery%20sale">	<h5> (+971) 569984153 </h5></a>
							</li>
                            
                            
                            
					  </ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>






<footer class="third-bg">
	
	<div class="footer_bottom fourth-bg">
		
        
        
          <p> 2017 &copy; Callabattery.ae All rights Reserved. </p>
        <a href="#" class="backtop"> ^ </a>
    </div>
				
</footer>


<script src="jss/jquery.min.js"></script>
<script src="jss/bootstrap.min.js"></script>
<script src="jss/interface.js"></script> 
<script type="text/javascript"> 
	$(document).ready(function(){
	$("#menu_slide").click(function(){
		$("#navbar").slideToggle('normal');
	});
	});
 </script>


<script type="text/javascript">
$(document).ready(function(){
  $('#navbar > ul > li:has(ul)').addClass("has-sub");
  $('#navbar > ul > li > a').click(function() {
    var checkElement = $(this).next();
    $('#navbar li').removeClass('dropdown');
    $(this).closest('li').addClass('dropdown');	
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
      $(this).closest('li').removeClass('dropdown');
      checkElement.slideUp('normal');
    }
    if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
      $('#navbar ul ul:visible').slideUp('normal');
      checkElement.slideDown('normal');
    }
    if (checkElement.is('ul')) {
      return false;
    } else {
      return true;	
    }		
  });
});



</script>
<script type="text/javascript">	
$("#navbar").on("click", function(event){
    event.stopPropagation();
});
$(".dropdown-menu").on("click", function(event){
    event.stopPropagation();
});
$(document).on("click", function(event){
    $(".dropdown-menu").slideUp('normal');
});	

$(".navbar-header").on("click", function(event){
    event.stopPropagation();
});
$(document).on("click", function(event){
    $("#navbar").slideUp('normal');
});		
</script>




<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/595a27ab50fd5105d0c83ac4/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->



<!-- Google Code for CALL A BATTERT _ CONVERSION Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 859425900;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "mJapCK3z_3MQ7JjnmQM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/859425900/?label=mJapCK3z_3MQ7JjnmQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>



</body>

  </html>
